<?php 

	
	if (!isset($_SESSION['loginAdmin'])) {
		header("Location: ../login");
	}


 ?>