<?php 
	$link = mysqli_connect("localhost", "root", "", "e_perpus");
 ?>