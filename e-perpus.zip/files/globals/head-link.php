<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Favicon-->
	<link rel="shortcut icon" href="vendor/img/smkn5.jpg">
	<!-- Author Meta -->
	<meta name="author" content="ItsZami - www.codecrime.net">
	<!-- Meta Description -->
	<meta name="description" content="E- Perpus merupakan kumpulan berbagai macam ebook yang bisa anda download kapanpun">
	<!-- Meta Keyword -->
	<meta name="keywords" content="E- Perpus SMKN5 Kota Bekasi">
	<!-- meta character set -->
	<meta charset="UTF-8">
	<!-- Site Title -->

	<!--
			Google Font
			============================================= -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,500,600" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500i" rel="stylesheet">

	<!--
			CSS
			============================================= -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/themify-icons/0.1.2/css/themify-icons.css">
	<link rel="stylesheet" href="vendor/css/linearicons.css">
	<link rel="stylesheet" href="vendor/css/font-awesome.min.css">
	<link rel="stylesheet" href="vendor/css/bootstrap.css">
	<link rel="stylesheet" href="vendor/css/magnific-popup.css">
	<link rel="stylesheet" href="vendor/css/nice-select.css">
	<link rel="stylesheet" href="vendor/css/animate.min.css">
	<link rel="stylesheet" href="vendor/css/owl.carousel.css">
	<link rel="stylesheet" href="vendor/css/main.css">